const myslider = document.querySelectorAll('.slider');
const dot = document.querySelectorAll(".dot");

let counter = 1;
sliderFun(counter);

let timer = setInterval(autoslide, 8000);
function autoslide() {
	counter += 1;
	sliderFun(counter);
}

function plusSlide(n){
	counter += n;
	sliderFun(counter);
	resetTimer();
}

function currentSlider(n){
	counter = n;
	sliderFun(counter);
	resetTimer();
}

function resetTimer() {
	clearInterval(timer);
	timer = SetInterval(autoslide, 8000);
}

function sliderFun(n) {
	let i;
	for(i = 0;i < myslider.length; i++) {
		myslider[i].style.display = "none";
	}
	for(i = 0; i < dot.length; i++) {
		dot[i].classList.remove('active');
	}
	if(n > myslider.length) {
		counter = 1;
	}
	if(n < 1) {
		counter = myslider.length;
	}
	myslider[counter -1].style.display = "block";
	dot[counter - 1].classList.add('active');
}
jQuery(document).ready(function(){
	jQuery('.mobile-icon').on('click', function(){
		jQuery('.menu').toggle();
	});
	jQuery('.menu li a').on('click', function(){
		jQuery(this).next('ul').toggle();
	});
	jQuery(window).resize(function() {
		let screen_size = jQuery(window).width();
		if(screen_size > 800) {
			jQuery('.menu').show();
		}
	});
});